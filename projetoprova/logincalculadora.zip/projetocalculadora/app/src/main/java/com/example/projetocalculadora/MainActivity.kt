package com.example.projetocalculadora

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doOnTextChanged

class MainActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var senhaEditText: EditText
    private lateinit var entrarButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        emailEditText = findViewById(R.id.edit_email)
        senhaEditText = findViewById(R.id.edit_senha)
        entrarButton = findViewById(R.id.bt_entrar)

        entrarButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val senha = senhaEditText.text.toString()

            // Verificar se o email e a senha correspondem às credenciais válidas
            if (email == "usuario@gmail.com" && senha == "senha123") {
                // Credenciais válidas, direcionar para a tela principal do aplicativo
                val intent = Intent(this, Novo_layout_Activity::class.java)
                startActivity(intent)
                finish() // Para impedir que o usuário volte para a tela de login pressionando o botão "Voltar"
            } else {
                // Credenciais inválidas, exibir uma mensagem de erro ou tomar outra ação apropriada
                // Por exemplo, exibir uma mensagem de erro ou limpar os campos de entrada
                // Toast.makeText(this, "Credenciais inválidas", Toast.LENGTH_SHORT).show()
                // emailEditText.text.clear()
                // senhaEditText.text.clear()
            }
        }
    }
}